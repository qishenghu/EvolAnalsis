# DUET\* Main Experiments — Raw Data & Sources

**Last updated**: 2026-05-04
**Author**: this is the canonical data file used to populate `tables/*.tex`. Edit here first, then regenerate tables.

All numbers are **val@100 strict success rate** (score $\geq 1.0$) unless otherwise noted.

---

## Hardware & training protocol

| Item | Value |
|---|---|
| Models | Qwen2.5-1.5B-Instruct, Qwen2.5-3B-Instruct |
| Teacher (offline cache) | Qwen2.5-72B-Instruct |
| Hardware | 4×A100-80GB (this server) + 4×L20X-144GB (collaborator) |
| Training steps | 100 |
| Validation set | 200 tasks per env, n=1 rollout per task |
| Rollout group size n | 8 (= 7 on-policy + 1 teacher-mixed) |
| Teacher data | 19K AF / 26K WS filtered Qwen-72B trajectories, all stored reward = 1.0, replay-verified ✓ |
| Optimizer | AdamW, lr 1e-6 |
| KL coef | 0.001 (WS) / 0.005 (AF) |

---

## 1.5B AlfWorld

| Method | Success Rate | Reward Mean | Source |
|---|---|---|---|
| OnPolicy GRPO | **1.0%** | 0.010 | local log `alfworld_qwen1.5b_onpolicy.log` (collapsed at step 85+) |
| LUFFY | **5.5%** | 0.055 | local log `alfworld_qwen1.5b_luffy.log` (collapsed) |
| CHORD | **27.0%** | 0.270 | local log `alfworld_qwen1.5b_chord.log` |
| SFT + GRPO | **30.0%** | 0.300 | local log `alfworld_qwen1.5b_sft_rl.log` (50 SFT + 50 GRPO) |
| **DUET\* (v39c_postfix)** | **47.5%** | **0.475** | local log `alfworld_qwen1.5b_duet_v39c_postfix.log` (single seed) |

**SOTA config** (DUET\*): peak=0.3, valley=0.05, mode=disc_acc, d_floor=0.4, ema_alpha=0.5, token_weighting=false.

---

## 1.5B WebShop

| Method | Success Rate | Reward Mean | Source |
|---|---|---|---|
| OnPolicy GRPO | **0.5%** | 0.152 | local log (collapsed) |
| SFT (no RL) | **7.0%** | 0.562 | local log (reference, not RL baseline) |
| LUFFY | **5.5%** | 0.573 | local log `webshop_qwen1.5b_luffy.log` |
| CHORD | **11.5%** | 0.603 | local log `webshop_qwen1.5b_chord.log` |
| SFT + GRPO | **18.5%** | 0.641 | local log (strongest baseline) |
| **DUET\* (swC_02)** | **36.0%** | **0.706** | local log `webshop_qwen1.5b_duet_swC_02_pk03_v10_floor06.log` (single seed) |

**SOTA config** (DUET\*): peak=0.3, valley=0.10, mode=disc_acc, d_floor=0.6, ema_alpha=0.2, token_weighting=false.

⚠ **Reproducibility note**: Recent re-runs of swC_02 on this server (2026-05-03/04) yielded 1.0–4.5% — likely high single-seed variance on 1.5B WS (other swC* configs span 13.5–36% on similar params). Multi-seed re-runs recommended before camera-ready.

---

## 3B AlfWorld

| Method | Success Rate | Reward Mean | Source |
|---|---|---|---|
| OnPolicy GRPO | **47.0%** | 0.470 | L20X server (collaborator) |
| LUFFY | **61.5%** | 0.615 | L20X server |
| CHORD | **67.0%** | 0.670 | L20X server (strongest baseline) |
| SFT + GRPO | **59.5%** | 0.595 | L20X server |
| **DUET\* (v39b)** | **77.5%** | **0.775** | L20X server (current SOTA, single seed) |

**Note**: All 3B AlfWorld numbers are from the L20X server (4×L20X-144GB), where the 3B AF experiments were run. Same codebase, same configs, same teacher data — verified by joint repository.

---

## 3B WebShop

| Method | Success Rate | Reward Mean | Source |
|---|---|---|---|
| OnPolicy GRPO | **2.0%** | TBD | L20X server (collapsed without expert guidance) |
| LUFFY | **38.0%** | TBD | L20X server (recent reproduction; paper claim is 49.5%) |
| CHORD | **39.0%** | TBD | L20X server (strongest baseline) |
| SFT + GRPO | **24.0%** | TBD | L20X server |
| **DUET\* (v39b)** | **45.5%** | **0.743** | L20X server (current SOTA, single seed); local 4×A100 reproduction = 44.0% (within ±1.5pp variance) |

**Reproducibility finding**: When we attempted to reproduce LUFFY independently on 4×A100, the result was 3.5% strict success rate (11.5% lenient, $\text{score} \geq 0.9$) — substantially below the 38.0% L20X reproduction and the 49.5% paper claim. This suggests LUFFY exhibits high cross-infrastructure variance on 3B WebShop. **L20X's 38.0%** is used as the reported baseline (more conservative against ourselves).

---

## Summary table for `tables/main_results.tex`

| Method | 1.5B-AF | 1.5B-WS | 3B-AF | 3B-WS |
|---|---|---|---|---|
| OnPolicy GRPO | 1.0% | 0.5% | 47.0% | 2.0% |
| SFT (no RL) | — | 7.0% | — | — |
| LUFFY | 5.5% | 5.5% | 61.5% | 38.0% |
| CHORD | 27.0% | 11.5% | 67.0% | 39.0% |
| SFT + GRPO | 30.0% | 18.5% | 59.5% | 24.0% |
| **DUET\* (Ours)** | **47.5%** | **36.0%** | **77.5%** | **45.5%** |
| **Δ vs best baseline** | +17.5pp | +17.5pp | +10.5pp | +6.5pp |
| **Avg Δ** | | | | **+13.0pp** |

---

## Open items / TODO

- [ ] Verify 3B WebShop reward means for baselines (4 cells in `main_results_with_reward.tex`)
- [ ] Multi-seed runs for 1.5B WebShop swC_02 (variance issue)
- [ ] Independent local reproduction of 3B AF SOTA on this server (currently L20X-only)
- [ ] LUFFY reproducibility study: why 3.5% (4×A100) vs 38.0% (L20X) vs 49.5% (paper claim)?

## Source files

- 1.5B local SOTA summary: `analysis_reports/1.5b_sota_summary.md`
- 1.5B master experiment table: `analysis_reports/1.5b_master_experiment_table.md`
- Cross-server results log: `analysis_reports/handoff/results_log.md`
- Theory analysis: `analysis_reports/why_duet_star_fails_3b_ws_2026-05-03.md`
- Empirical comparison: `analysis_reports/duet_bc_empirical_comparison_2026-05-03.md`
